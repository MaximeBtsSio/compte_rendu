#include <stdlib.h>
#include <stdio.h>
#include "journal.h"

int main()
{
return 0;
}
